 


import os
import shutil
from pathlib import Path
from time import time, sleep

 

while True:



    sleep(60 - time() % 60)

    paths = sorted(Path("Y:\\MfgSupport\\Reports\\Daily_Reports_3910").iterdir(), key = os.path.getctime)
    files = []



    for file in paths:
        if "xlsx" in file.name:
            if "DailyReport_3910_" in file.name:
                files.append(file)

    daily = str(files[-1])

    if "~$" in daily:
        daily = daily[:41] + daily[43:]



    paths = sorted(Path("Y:\\Temp\\Carlos Salas\\Daily Reports").iterdir(), key = os.path.getctime)
    files = []

 

    for file in paths:
        if "xlsx" in file.name:
            if "DailyReport_3910_" in file.name:
                files.append(file)
            else:
                files.append("No hay daily")
        else:
            files.append("No hay excel")
 
    actual = str(files[-1])

    if "~$" in actual:
        actual = actual[:35] + actual[37:]



    dailyDoc = daily[41:]
    actualDoc = actual[35:]

    print("nuevo: " + dailyDoc)
    print("actual: " + actualDoc)



    if actualDoc != dailyDoc:
        shutil.copy(daily, "Y:\\Temp\\Carlos Salas\\Daily Reports")
        print("daily actualizado!")

 

    'repetir iteracion cada minuto'


    